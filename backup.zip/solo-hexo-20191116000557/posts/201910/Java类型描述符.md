title: Java类型描述符
date: '2019-10-15 18:26:54'
updated: '2019-10-15 18:26:54'
tags: [Java类型描述符]
permalink: /articles/2019/10/15/1571135214150.html
---
变量类型在字节码中有特殊的写法,比如int会被写为I,float会被写为F,long会被写为J等等...

以下为Java代码中的变量类型和其在Java字节码中的类型描述符.| col1 | col2 | col3 |

 |:-- | :--: | :--: | :--: | 
 | 变量类型 | 类型描述符 | 包装类 | 包装类类型描述符 | 
 | int | I(大写i) | Integer | Ljava/lang/Integer; | 
 | short | S | Short | Ljava/lang/Short; | 
 | long | J | Long | Ljava/lang/Long; | 
 | boolean | Z | Boolean | Ljava/lang/Boolean; | 
 | char | C | Character | Ljava/lang/Character; | 
 | byte | B | Byte | Ljava/lang/Byte; | 
 | float | F | Float | Ljava/lang/Float; | 
 | double	 | D	 | Double | 	Ljava/lang/Double; | 
 | void	 | V	 | Void | 	Ljava/lang/Void; | 
 | Object	 | L+类名(使用'/'作为分隔符)+;如: Ljava/lang/Object; | Lorg/objectweb/asm/MethodVisitor;	 | /	 | / | 
 | String | 	Ljava/lang/String; | 	/	 | / | 
 |  | 数组写法: |  |  | 		
 | X的N维数组 | 	N个[+X的类型描述符 | 	/	 | / | 
 | int[]	 | [I	 | /	 | / | 
 | byte[][]	 | [[B | 	/ | 	/ | 
 | String[] | 	[Ljava/lang/String; | 	/ | 	/ | 
