title: 我在 GitHub 上的开源项目
date: '2019-10-09 18:16:15'
updated: '2019-10-09 18:16:15'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [AcFun-Android](https://github.com/HubertYoung/AcFun-Android) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`6`](https://github.com/HubertYoung/AcFun-Android/watchers "关注数")&nbsp;&nbsp;[⭐️`54`](https://github.com/HubertYoung/AcFun-Android/stargazers "收藏数")&nbsp;&nbsp;[🖖`14`](https://github.com/HubertYoung/AcFun-Android/network/members "分叉数")</span>

AcFun-Android



---

### 2. [AcFun](https://github.com/HubertYoung/AcFun) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/HubertYoung/AcFun/watchers "关注数")&nbsp;&nbsp;[⭐️`5`](https://github.com/HubertYoung/AcFun/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/HubertYoung/AcFun/network/members "分叉数")</span>

acfun bilibili资源文件



---

### 3. [Gesture](https://github.com/HubertYoung/Gesture) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/HubertYoung/Gesture/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/HubertYoung/Gesture/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/HubertYoung/Gesture/network/members "分叉数")</span>

自定义手势



---

### 4. [solo-blog](https://github.com/HubertYoung/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/HubertYoung/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/HubertYoung/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/HubertYoung/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://solo.hubertyoung.top:6422`](http://solo.hubertyoung.top:6422 "项目主页")</span>

HubertYoung 的个人博客 - 记录精彩的程序人生



---

### 5. [FrpsVersion](https://github.com/HubertYoung/FrpsVersion) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/HubertYoung/FrpsVersion/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/HubertYoung/FrpsVersion/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/HubertYoung/FrpsVersion/network/members "分叉数")</span>





---

### 6. [flutter_app](https://github.com/HubertYoung/flutter_app) <kbd title="主要编程语言">Dart</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/HubertYoung/flutter_app/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/HubertYoung/flutter_app/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/HubertYoung/flutter_app/network/members "分叉数")</span>

study flutter



---

### 7. [Tucao](https://github.com/HubertYoung/Tucao) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/HubertYoung/Tucao/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/HubertYoung/Tucao/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/HubertYoung/Tucao/network/members "分叉数")</span>

可运行demo



---

### 8. [Github_demo](https://github.com/HubertYoung/Github_demo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/HubertYoung/Github_demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/HubertYoung/Github_demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/HubertYoung/Github_demo/network/members "分叉数")</span>

这是第一个githubdemo-android studio

